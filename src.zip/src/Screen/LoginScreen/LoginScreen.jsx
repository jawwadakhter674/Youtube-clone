
import React from 'react'
import { useDispatch } from 'react-redux'
import { login } from '../../redux/action/auth-action';
import './LoginScreen.scss'
import youtube from './youtube.png'


function LoginScreen() {
     const dispatch =useDispatch();
     const handleCheck=()=>{
         
           login(dispatch)
            
     }

    return (
        <div className="login">
            <div className="login_container">
                <img src={youtube} alt="" />
                <button onClick={handleCheck}>LoginScreen</button>

                <p>Some Data about Login </p>
            </div>
        </div>
    )
}

export default LoginScreen
