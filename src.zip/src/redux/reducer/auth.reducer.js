import {login_request, load_profile, login_failed, login_success } from '../actionType'



const initialState = {
    accessToken:null,
    user:null,
    loading:false
}




export const authReducer =(prevState =initialState,action)=>{
    const {type,payload}=action;
    switch (type) {
        case login_request:
            return {
                ...prevState,
                loading:true
            }
        case login_success:
            return {
                ...prevState,
                accessToken:payload,
                loading:false
            }
        case login_failed:
            return {
                ...prevState,
                accessToken:null,
                loading:false,
                error:payload
            }
        case load_profile:
            return {
                ...prevState,
                
                user:payload
            }
           
    
        default:
        return prevState
    }

}