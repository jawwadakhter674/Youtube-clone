import firebase from 'firebase';
import Auth from '../../firebase';
import { load_profile, login_failed, login_request, login_success } from '../actionType';



export const login = (dispatch) => {



    dispatch({
        type: login_request
    })
    const provider = new firebase.auth.GoogleAuthProvider();
    // const response =auth.signInWithPopup(provider)





    Auth
        .signInWithPopup(provider)
        .then((result) => {

            var credential = result.credential;

            console.log(credential)
            var token = credential.accessToken;
            console.log(token)

            var user = result.user;
            console.log(user)

            // console.log(user.displayName)

            const profile = {
                name: user.displayName,
                photoURL: user.photoURL
            }
            console.log(profile);

            dispatch({
                type: login_success,
                payload: token,
            })
            dispatch({
                type: load_profile,
                payload: profile
            })

        }).catch((error) => {
            console.log(error.message)
            //    console.log(error.message);
            dispatch({
                type: login_failed,
                payload: error.message
            })


        });




}













































const googleLogin = ()=>{

    dp.collection('messages').add({
      
      username:username,
      photoUrl:user.photoURL,
      timestamp:firebase.firestore.FieldValue.serverTimestamp()
    })





    let dispatch = useDispatch()
auth.signInWithPopup(googleAuthProvider)
.then(async (result )=>{
// we get the result  from that result we can destruct the user...

console.log(result)
const {user} = result ;



//   const user  = {
//     user:result.user,
//     displayName: user.displayName,
//     photoUrl:user.photoURL,
//  }

//  console.log(user,'hy')


const idTokenResult = await user.getIdTokenResult()
//making request our own on backend get the response from there based on user role..

// In redux data update.....
dispatch({ 
type:"LOGGED_IN_USER",
payload:{ 
  email: user.email,
  token:idTokenResult.token,
     }
 
});



const {user} = useSelector((state)=>
({...state})         
)

console.log(user,'coming user')


// redirect the user from many way...


})

.catch(error=>{
  console.log(error)
  toast.error(error.message)
})
}

// Noor sent Today at 22:20
///In redux data get from store .........

   

  

  
